document.addEventListener("DOMContentLoaded", function () {
    const username = "admin";
    const password = "test123";

    const form = document.getElementById("loginForm");
    const errorMessage = document.getElementById("error-message");
    const successMessage = document.getElementById("success-message");
    const loginContainer = document.querySelector(".login-container");

    form.addEventListener("submit", function (event) {
        event.preventDefault();

        const enteredUsername = document.getElementById("username").value;
        const enteredPassword = document.getElementById("password").value;

        if (enteredUsername === username && enteredPassword === password) {
            // Successful login
            errorMessage.textContent = "";
            successMessage.textContent = "Login successful!";
            loginContainer.style.border = "2px solid green";
        } else {
            // Incorrect credentials
            successMessage.textContent = "";
            errorMessage.textContent = "Incorrect username or password. Please try again.";
            loginContainer.style.border = "2px solid red";
        }
    });
});